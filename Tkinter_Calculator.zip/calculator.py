"""calculator.py - Tkinter Calculator""" 
# minimal example
import tkinter as tk
root=tk.Tk()
root.title("Calculator")
label=tk.Label(root,text="Calculator Running")
label.pack()
root.mainloop()
